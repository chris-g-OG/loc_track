# locshare

You create a short-lived link, send it to someone, they open it and see who is
asking and why. If they press the button *and* allow their browser's prompt,
their coordinates come back to you — stored in SQLite, optionally pushed to
Telegram or a webhook.

## What is actually possible

There is no way to pull GPS coordinates out of a browser without the operating
system's permission prompt. It is enforced by the browser, not by politeness,
and there is no flag, header or API that bypasses it. So every honest version of
this is consent-based.

| Approach | Accuracy | Prompt? |
|---|---|---|
| Geolocation API (this project) | 5–50 m on a phone with GPS | Yes — they tap "Allow" |
| IP lookup | city-level, often 10–50 km off, useless on mobile carriers | No |

IP lookup is the only "silent" option and it is worthless for anything real:
Greek mobile carriers commonly route traffic so that a phone in Chania geolocates
to Athens. This project does not use it.

Two further constraints worth knowing before you deploy:

- **HTTPS is mandatory.** `navigator.geolocation` only exists in a secure
  context. On plain http the page loads and the button does nothing.
- **Accuracy depends on the device**, not on you. A phone outdoors gives you GPS
  (metres). A desktop on Wi-Fi gives you a Wi-Fi/IP estimate (hundreds of metres
  to kilometres). The `accuracy` figure is in metres and is stored with every
  report — always read it before trusting a position.

## Install on the VPS

```bash
sudo useradd --system --home /opt/locshare --shell /usr/sbin/nologin locshare
sudo mkdir -p /opt/locshare && sudo chown locshare:locshare /opt/locshare

sudo -u locshare git clone <your-repo> /opt/locshare     # or rsync the files
cd /opt/locshare
sudo -u locshare python3 -m venv venv
sudo -u locshare venv/bin/pip install -r requirements.txt

sudo -u locshare cp .env.example .env
sudo -u locshare python3 -c "import secrets; print(secrets.token_urlsafe(32))"
sudo -u locshare nano .env          # set BASE_URL, ADMIN_TOKEN, REQUESTER
sudo chmod 600 .env

sudo -u locshare venv/bin/python app.py init

sudo cp deploy/locshare.service /etc/systemd/system/
sudo systemctl enable --now locshare

sudo cp deploy/nginx.conf /etc/nginx/sites-available/locshare
sudo ln -s /etc/nginx/sites-available/locshare /etc/nginx/sites-enabled/
# add the limit_req_zone line to nginx.conf's http{} block, then:
sudo certbot --nginx -d loc.example.gr
sudo nginx -t && sudo systemctl reload nginx
```

## Use it

Make a link:

```bash
cd /opt/locshare
sudo -u locshare venv/bin/python app.py new \
  --label "Andreas, Saturday pickup" \
  --purpose "για να ξέρω πού να σε παραλάβω" \
  --hours 6
# -> https://loc.example.gr/s/xT9_pQm2K
```

`--purpose` is the sentence the recipient reads, so write it in their language.
`--label` is for your dashboard only.

Other commands:

```bash
app.py list                   # active links and what came back
app.py list --all             # including expired/revoked
app.py revoke <token>         # kill a link immediately
app.py purge                  # apply retention now
```

Or over HTTP:

```bash
curl -X POST https://loc.example.gr/api/links \
  -H "X-Admin-Token: $TOKEN" -H 'Content-Type: application/json' \
  -d '{"label":"Andreas","purpose":"για να ξέρω πού να σε παραλάβω","expires_hours":6}'
```

Dashboard: `https://loc.example.gr/admin?k=<admin token>` — it swaps the token
for an HttpOnly cookie and redirects, so the token does not linger in history.

## Design decisions

**Links expire and are single-use by default.** A link that works forever is a
tracking link. `--hours 6 --max-reports 1` is the default shape; raise
`--max-reports` only when you actually want several check-ins.

**Declines are recorded too.** If someone opens the link and refuses, you get a
row saying so with no position. Useful: you can tell "never opened it" from
"saw it and said no" without pestering them.

**IPs are truncated** to /24 (v4) or /48 (v6) before storage. Enough to notice
someone brute-forcing tokens, not enough to be another location signal.

**Retention runs on every write** rather than in a cron job, because a cron job
that stops firing fails silently and leaves you holding data you promised to
delete.

**Every shared position comes with its own erase link**, shown to the recipient
after they share. They can delete it themselves without contacting you.

## The legal side

You work on GDPR compliance, so the short version: location data is personal
data, and a person's whereabouts is about as sensitive as non-special-category
data gets. What keeps this lawful is that the recipient is told who is asking,
what for, and for how long it is kept — then affirmatively acts. That is Art. 6(1)(a)
consent: freely given, specific, informed, unambiguous. The consent page is built
to satisfy each of those words, and the stored row is your record of it.

Where it goes wrong:

- **Misdescribing the purpose.** "Verify your account" on a link that only
  collects position is not informed consent, and it is the exact pattern that
  turns this into a phishing tool.
- **Sending it to someone who does not know you.** Consent obtained by
  deception is not consent.
- **Using it to monitor a specific person** — a partner, an ex, an employee off
  the clock. Beyond GDPR, covert location monitoring of an individual in Greece
  can reach Art. 370A of the Penal Code and the stalking provisions. The link
  being consent-based does not save you if the surrounding conduct is coercive.
- **Employees.** Even with a signed consent form, consent from an employee is
  rarely "freely given" in the GDPR sense because of the power imbalance
  (EDPB Opinion 2/2017). If you build a fleet or field-staff version of this for
  an SMB client, the lawful basis is legitimate interest with a DPIA, not
  consent, and it needs a written policy the staff have seen.

If you offer this to clients as a service, you are a processor for them and they
are the controller — which means a Art. 28 processing agreement, and the
retention figure in `.env` should match whatever their policy says.

## Layout

```
app.py                  service + CLI
templates/share.html    the consent page the recipient sees
templates/dashboard.html your view of links and reports
templates/erase.html    recipient-initiated deletion
deploy/                 systemd unit + nginx config
.env.example            configuration
```
