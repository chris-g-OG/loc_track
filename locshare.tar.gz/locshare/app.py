#!/usr/bin/env python3
"""
locshare - consent-based location request links.

You create a short-lived link, send it to someone, they open it and see who is
asking and why. Nothing is collected until they press the button and then also
allow their browser's location prompt. The coordinates are POSTed back here,
stored in SQLite, and optionally pushed to Telegram or a webhook.

There is no way to get GPS coordinates from a browser without that prompt.
Anything that claims otherwise is doing IP geolocation, which is city-level at
best and usually wrong on mobile networks.
"""

from __future__ import annotations

import argparse
import hmac
import json
import os
import secrets
import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from functools import wraps
from urllib import error as urlerror
from urllib import parse as urlparse
from urllib import request as urlrequest

from flask import (Flask, abort, g, jsonify, make_response, redirect,
                   render_template, request)

APP_DIR = os.path.dirname(os.path.abspath(__file__))


def _load_env_file(path: str) -> None:
    """Minimal .env loader so systemd and local runs behave the same."""
    if not os.path.exists(path):
        return
    with open(path, "r", encoding="utf-8") as fh:
        for raw in fh:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            os.environ.setdefault(key, val)


_load_env_file(os.path.join(APP_DIR, ".env"))

DB_PATH = os.environ.get("LOCSHARE_DB", os.path.join(APP_DIR, "locshare.db"))
ADMIN_TOKEN = os.environ.get("LOCSHARE_ADMIN_TOKEN", "")
BASE_URL = os.environ.get("LOCSHARE_BASE_URL", "http://127.0.0.1:8080").rstrip("/")
TG_TOKEN = os.environ.get("LOCSHARE_TELEGRAM_TOKEN", "")
TG_CHAT = os.environ.get("LOCSHARE_TELEGRAM_CHAT_ID", "")
WEBHOOK_URL = os.environ.get("LOCSHARE_WEBHOOK_URL", "")
REQUESTER = os.environ.get("LOCSHARE_REQUESTER", "the person who sent you this link")
CONTACT = os.environ.get("LOCSHARE_CONTACT", "")
RETENTION_DAYS = int(os.environ.get("LOCSHARE_RETENTION_DAYS", "30"))

app = Flask(__name__, template_folder=os.path.join(APP_DIR, "templates"))
app.config["JSON_SORT_KEYS"] = False

SCHEMA = """
CREATE TABLE IF NOT EXISTS links (
    token           TEXT PRIMARY KEY,
    label           TEXT NOT NULL,
    purpose         TEXT NOT NULL,
    requester       TEXT NOT NULL,
    created_at      TEXT NOT NULL,
    expires_at      TEXT NOT NULL,
    max_reports     INTEGER NOT NULL DEFAULT 1,
    retention_days  INTEGER NOT NULL DEFAULT 30,
    revoked         INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS reports (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    token        TEXT NOT NULL,
    erase_token  TEXT NOT NULL UNIQUE,
    received_at  TEXT NOT NULL,
    status       TEXT NOT NULL,
    lat          REAL,
    lon          REAL,
    accuracy     REAL,
    altitude     REAL,
    heading      REAL,
    speed        REAL,
    fixed_at     TEXT,
    user_agent   TEXT,
    ip_prefix    TEXT,
    note         TEXT
);

CREATE INDEX IF NOT EXISTS idx_reports_token ON reports(token);
CREATE INDEX IF NOT EXISTS idx_reports_time  ON reports(received_at);
"""


# --------------------------------------------------------------------------
# storage
# --------------------------------------------------------------------------

def connect() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = connect()
    return g.db


@app.teardown_appcontext
def close_db(_exc=None) -> None:
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db() -> None:
    conn = connect()
    with conn:
        conn.executescript(SCHEMA)
    conn.close()


def now() -> datetime:
    return datetime.now(timezone.utc)


def iso(dt: datetime) -> str:
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_iso(s: str) -> datetime:
    return datetime.strptime(s, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


def purge_expired(conn: sqlite3.Connection) -> int:
    """Delete reports past their link's retention window. Storage limitation
    is not optional under GDPR, so this runs on every report and admin view
    rather than sitting in a cron job that can silently stop firing."""
    rows = conn.execute("SELECT token, retention_days FROM links").fetchall()
    removed = 0
    with conn:
        for row in rows:
            cutoff = iso(now() - timedelta(days=int(row["retention_days"])))
            cur = conn.execute(
                "DELETE FROM reports WHERE token = ? AND received_at < ?",
                (row["token"], cutoff),
            )
            removed += cur.rowcount or 0
    return removed


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------

def client_ip_prefix() -> str:
    """Truncated client IP. Full addresses are personal data we do not need;
    a /24 or /48 is enough to spot abuse of a link."""
    xff = request.headers.get("X-Forwarded-For", "")
    ip = xff.split(",")[0].strip() if xff else (request.remote_addr or "")
    if not ip:
        return ""
    if ":" in ip:
        parts = [p for p in ip.split(":") if p != ""]
        return ":".join(parts[:3]) + "::/48"
    parts = ip.split(".")
    if len(parts) == 4:
        return ".".join(parts[:3]) + ".0/24"
    return ""


def link_state(row: sqlite3.Row, report_count: int) -> str:
    if row["revoked"]:
        return "revoked"
    if now() > parse_iso(row["expires_at"]):
        return "expired"
    if report_count >= int(row["max_reports"]):
        return "used"
    return "active"


def admin_ok() -> bool:
    if not ADMIN_TOKEN:
        return False
    supplied = (
        request.headers.get("X-Admin-Token")
        or request.cookies.get("locshare_admin")
        or request.args.get("k")
        or ""
    )
    return hmac.compare_digest(supplied, ADMIN_TOKEN)


def require_admin(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not admin_ok():
            abort(401)
        return fn(*args, **kwargs)

    return wrapper


def notify(link: sqlite3.Row, report: dict) -> None:
    """Best effort push. A dead Telegram token must never lose a report."""
    if report.get("status") == "granted":
        lat, lon = report["lat"], report["lon"]
        maps = f"https://www.google.com/maps?q={lat},{lon}"
        osm = f"https://www.openstreetmap.org/?mlat={lat}&mlon={lon}#map=17/{lat}/{lon}"
        acc = report.get("accuracy")
        acc_txt = f"+/-{acc:.0f} m" if isinstance(acc, (int, float)) else "unknown accuracy"
        text = (
            f"Location shared: {link['label']}\n"
            f"{lat:.6f}, {lon:.6f} ({acc_txt})\n"
            f"{maps}\n{osm}"
        )
    else:
        text = (
            f"Link opened but not shared: {link['label']}\n"
            f"Outcome: {report.get('status')} - {report.get('note') or 'no detail'}"
        )

    if TG_TOKEN and TG_CHAT:
        try:
            payload = urlparse.urlencode(
                {"chat_id": TG_CHAT, "text": text, "disable_web_page_preview": "true"}
            ).encode()
            req = urlrequest.Request(
                f"https://api.telegram.org/bot{TG_TOKEN}/sendMessage", data=payload
            )
            urlrequest.urlopen(req, timeout=5).read()
        except (urlerror.URLError, OSError, ValueError) as exc:
            app.logger.warning("telegram push failed: %s", exc)

    if WEBHOOK_URL:
        try:
            body = json.dumps({"link": link["label"], "text": text, **report}).encode()
            req = urlrequest.Request(
                WEBHOOK_URL, data=body, headers={"Content-Type": "application/json"}
            )
            urlrequest.urlopen(req, timeout=5).read()
        except (urlerror.URLError, OSError, ValueError) as exc:
            app.logger.warning("webhook push failed: %s", exc)


def create_link(label: str, purpose: str, expires_hours: int, max_reports: int,
                retention_days: int, requester: str) -> str:
    token = secrets.token_urlsafe(9)
    conn = connect()
    with conn:
        conn.execute(
            "INSERT INTO links (token, label, purpose, requester, created_at,"
            " expires_at, max_reports, retention_days, revoked)"
            " VALUES (?,?,?,?,?,?,?,?,0)",
            (
                token,
                label,
                purpose,
                requester,
                iso(now()),
                iso(now() + timedelta(hours=expires_hours)),
                max_reports,
                retention_days,
            ),
        )
    conn.close()
    return token


# --------------------------------------------------------------------------
# public routes
# --------------------------------------------------------------------------

@app.route("/healthz")
def healthz():
    return jsonify(ok=True, time=iso(now()))


@app.route("/s/<token>")
def share_page(token: str):
    db = get_db()
    link = db.execute("SELECT * FROM links WHERE token = ?", (token,)).fetchone()
    if link is None:
        abort(404)
    count = db.execute(
        "SELECT COUNT(*) c FROM reports WHERE token = ? AND status = 'granted'",
        (token,),
    ).fetchone()["c"]
    state = link_state(link, count)
    resp = make_response(
        render_template(
            "share.html",
            token=token,
            link=link,
            state=state,
            contact=CONTACT,
            retention_days=link["retention_days"],
            remaining=max(0, int(link["max_reports"]) - count),
        )
    )
    resp.headers["Referrer-Policy"] = "no-referrer"
    resp.headers["X-Robots-Tag"] = "noindex, nofollow"
    return resp


@app.route("/s/<token>/report", methods=["POST"])
def report(token: str):
    db = get_db()
    link = db.execute("SELECT * FROM links WHERE token = ?", (token,)).fetchone()
    if link is None:
        abort(404)

    count = db.execute(
        "SELECT COUNT(*) c FROM reports WHERE token = ? AND status = 'granted'",
        (token,),
    ).fetchone()["c"]
    state = link_state(link, count)
    if state != "active":
        return jsonify(ok=False, error=state), 410

    data = request.get_json(silent=True) or {}
    status = str(data.get("status", "error"))
    if status not in {"granted", "denied", "unavailable", "timeout", "error"}:
        status = "error"

    rec = {
        "status": status,
        "lat": None,
        "lon": None,
        "accuracy": None,
        "altitude": None,
        "heading": None,
        "speed": None,
        "fixed_at": None,
        "note": (str(data.get("note", ""))[:300] or None),
    }

    if status == "granted":
        try:
            rec["lat"] = float(data["lat"])
            rec["lon"] = float(data["lon"])
        except (KeyError, TypeError, ValueError):
            return jsonify(ok=False, error="bad coordinates"), 400
        if not (-90 <= rec["lat"] <= 90 and -180 <= rec["lon"] <= 180):
            return jsonify(ok=False, error="coordinates out of range"), 400
        for key in ("accuracy", "altitude", "heading", "speed"):
            val = data.get(key)
            if isinstance(val, (int, float)):
                rec[key] = float(val)
        ts = data.get("timestamp")
        if isinstance(ts, (int, float)):
            rec["fixed_at"] = iso(datetime.fromtimestamp(ts / 1000.0, timezone.utc))

    erase_token = secrets.token_urlsafe(12)
    with db:
        db.execute(
            "INSERT INTO reports (token, erase_token, received_at, status, lat, lon,"
            " accuracy, altitude, heading, speed, fixed_at, user_agent, ip_prefix, note)"
            " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                token,
                erase_token,
                iso(now()),
                rec["status"],
                rec["lat"],
                rec["lon"],
                rec["accuracy"],
                rec["altitude"],
                rec["heading"],
                rec["speed"],
                rec["fixed_at"],
                request.headers.get("User-Agent", "")[:300],
                client_ip_prefix(),
                rec["note"],
            ),
        )
    purge_expired(db)
    notify(link, rec)

    return jsonify(
        ok=True,
        status=rec["status"],
        erase_url=f"{BASE_URL}/e/{erase_token}" if rec["status"] == "granted" else None,
    )


@app.route("/e/<erase_token>", methods=["GET", "POST"])
def erase(erase_token: str):
    """Lets the person who shared delete what they shared, without an account.
    This is the right-to-erasure path; keep the URL on the confirmation page."""
    db = get_db()
    row = db.execute(
        "SELECT * FROM reports WHERE erase_token = ?", (erase_token,)
    ).fetchone()
    if request.method == "POST":
        if row is not None:
            with db:
                db.execute("DELETE FROM reports WHERE erase_token = ?", (erase_token,))
        return render_template("erase.html", done=True, found=True, contact=CONTACT)
    return render_template(
        "erase.html", done=False, found=row is not None, contact=CONTACT
    )


# --------------------------------------------------------------------------
# admin routes
# --------------------------------------------------------------------------

@app.route("/admin")
def dashboard():
    if not admin_ok():
        abort(401)
    if request.args.get("k"):
        resp = redirect("/admin")
        resp.set_cookie(
            "locshare_admin",
            ADMIN_TOKEN,
            httponly=True,
            samesite="Lax",
            secure=BASE_URL.startswith("https"),
            max_age=60 * 60 * 24 * 14,
        )
        return resp

    db = get_db()
    purge_expired(db)
    links = []
    for row in db.execute("SELECT * FROM links ORDER BY created_at DESC").fetchall():
        reports = db.execute(
            "SELECT * FROM reports WHERE token = ? ORDER BY received_at DESC",
            (row["token"],),
        ).fetchall()
        granted = [r for r in reports if r["status"] == "granted"]
        links.append(
            {
                "row": row,
                "url": f"{BASE_URL}/s/{row['token']}",
                "state": link_state(row, len(granted)),
                "reports": reports,
            }
        )
    return render_template("dashboard.html", links=links, base_url=BASE_URL)


@app.route("/api/links", methods=["POST"])
@require_admin
def api_create_link():
    data = request.get_json(silent=True) or {}
    label = str(data.get("label", "")).strip()
    if not label:
        return jsonify(ok=False, error="label is required"), 400
    token = create_link(
        label=label[:120],
        purpose=str(data.get("purpose", "")).strip()[:500]
        or "to know where to meet you",
        expires_hours=int(data.get("expires_hours", 24)),
        max_reports=int(data.get("max_reports", 1)),
        retention_days=int(data.get("retention_days", RETENTION_DAYS)),
        requester=str(data.get("requester", REQUESTER))[:120],
    )
    return jsonify(ok=True, token=token, url=f"{BASE_URL}/s/{token}")


@app.route("/api/links/<token>", methods=["DELETE"])
@require_admin
def api_revoke(token: str):
    db = get_db()
    with db:
        cur = db.execute("UPDATE links SET revoked = 1 WHERE token = ?", (token,))
    if not cur.rowcount:
        return jsonify(ok=False, error="not found"), 404
    return jsonify(ok=True, token=token, revoked=True)


@app.route("/api/links/<token>/reports")
@require_admin
def api_reports(token: str):
    db = get_db()
    rows = db.execute(
        "SELECT id, received_at, status, lat, lon, accuracy, fixed_at, note"
        " FROM reports WHERE token = ? ORDER BY received_at DESC",
        (token,),
    ).fetchall()
    return jsonify(ok=True, token=token, reports=[dict(r) for r in rows])


# --------------------------------------------------------------------------
# CLI
# --------------------------------------------------------------------------

def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="locshare")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("init", help="create the database")

    new = sub.add_parser("new", help="create a link")
    new.add_argument("--label", required=True, help="what this link is for (your eyes)")
    new.add_argument("--purpose", default="to know where to meet you",
                     help="shown to the recipient, in their language")
    new.add_argument("--hours", type=int, default=24, help="link lifetime")
    new.add_argument("--max-reports", type=int, default=1)
    new.add_argument("--retention-days", type=int, default=RETENTION_DAYS)
    new.add_argument("--requester", default=REQUESTER)

    lst = sub.add_parser("list", help="list links and their reports")
    lst.add_argument("--all", action="store_true", help="include expired and revoked")

    rev = sub.add_parser("revoke", help="kill a link now")
    rev.add_argument("token")

    srv = sub.add_parser("serve", help="development server")
    srv.add_argument("--host", default="127.0.0.1")
    srv.add_argument("--port", type=int, default=8080)

    sub.add_parser("purge", help="apply retention now")

    args = parser.parse_args(argv)
    init_db()

    if args.cmd == "init":
        print(f"database ready at {DB_PATH}")
        return 0

    if args.cmd == "new":
        token = create_link(
            args.label, args.purpose, args.hours, args.max_reports,
            args.retention_days, args.requester,
        )
        print(f"{BASE_URL}/s/{token}")
        return 0

    if args.cmd == "list":
        conn = connect()
        for row in conn.execute("SELECT * FROM links ORDER BY created_at DESC"):
            reports = conn.execute(
                "SELECT * FROM reports WHERE token = ? ORDER BY received_at DESC",
                (row["token"],),
            ).fetchall()
            granted = [r for r in reports if r["status"] == "granted"]
            state = link_state(row, len(granted))
            if state != "active" and not args.all:
                continue
            print(f"[{state:8}] {row['label']}  {BASE_URL}/s/{row['token']}")
            print(f"{'':11}expires {row['expires_at']}  "
                  f"reports {len(granted)}/{row['max_reports']}")
            for rep in reports:
                if rep["status"] == "granted":
                    print(f"{'':11}  {rep['received_at']}  "
                          f"{rep['lat']:.6f},{rep['lon']:.6f}  "
                          f"+/-{(rep['accuracy'] or 0):.0f}m")
                else:
                    print(f"{'':11}  {rep['received_at']}  {rep['status']}")
        conn.close()
        return 0

    if args.cmd == "revoke":
        conn = connect()
        with conn:
            cur = conn.execute(
                "UPDATE links SET revoked = 1 WHERE token = ?", (args.token,)
            )
        conn.close()
        print("revoked" if cur.rowcount else "no such link")
        return 0 if cur.rowcount else 1

    if args.cmd == "purge":
        conn = connect()
        removed = purge_expired(conn)
        conn.close()
        print(f"removed {removed} report(s) past retention")
        return 0

    if args.cmd == "serve":
        if not ADMIN_TOKEN:
            print("warning: LOCSHARE_ADMIN_TOKEN is unset, /admin is locked out",
                  file=sys.stderr)
        app.run(host=args.host, port=args.port, debug=False)
        return 0

    return 1


init_db()

if __name__ == "__main__":
    raise SystemExit(main())
